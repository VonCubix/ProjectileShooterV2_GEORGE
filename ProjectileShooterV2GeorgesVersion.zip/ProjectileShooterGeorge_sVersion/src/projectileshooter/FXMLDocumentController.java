/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectileshooter;

import java.awt.Point;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author cstuser
 */
public class FXMLDocumentController implements Initializable {

    private double lastFrameTime = 0.0;

    @FXML
    private AnchorPane pane;

    @FXML
    private Label coordinates;

    @FXML
    private ImageView gunImage;

    @FXML
    private ImageView character;

    @FXML
    private RadioButton radioButtonFireGun;
    @FXML
    private RadioButton radioButtonIceGun;
    @FXML
    private RadioButton radioButtonAGGun;
    @FXML
    private RadioButton radioButtonPortalGun;

    //Local Variables
    ArrayList<Double> values = new ArrayList<Double>();
    public ArrayList<GameObject> objectList = new ArrayList<>();
    private ArrayList<Projectile> arrayListProjectiles = new ArrayList<>();

    private int counterProjectiles;
    private int counterBounces;

    //rectangles for detecting collisions with the edges of the game environment
    private Edge edgeRoof;
    private Edge edgeFloor;
    private Edge edgeLeftWall;
    private Edge edgeRightWall;
    
    private AntiGravity agLeftSide;
    private AntiGravity agRightSide;

    //private Gun gun;
    private boolean increasing = true;

    //Boolean to check if the projectile is within the bounds of an antigravity region
    private boolean isWithinAntiGravity = false;


    private Portal portalIn;
    private Portal portalOut;


    public  boolean portalInIsActive = false;
    public  boolean portalOutIsActive = false;
    //private boolean decreasing = false;

    public Point mouseAim;
    public Point gunPivot;

    //used in the calculation of the angle of the gun and the projectile initial velocity
    double theta;

    //Variables for the mouse's position within the game environment
    private double mouseX;
    private double mouseY;

    private Vector velocityProjectile;
    private Vector acceleration;
    private Projectile projectile;

    //Final variables
    private final double PROJECTILE_RADIUS = 10; // Radius of the projectiles
    private final double PROJECTILE_VELOCITY = 500; //Magnitude of the projectile's velocity
    private final double GRAVITY = 50; //Magnitude of gravity
    
    private final int MAX_NUMBER_OF_BOUNCES = 3;
    
    private final double GUN_LENGTH = 150; //equvallent to gunImage.getFitWidth() / 2; (original value 243)
    
    //Values used by portals and antigravity
    private final double PORTAL_WIDTH = 30;
    private final double PORTAL_HEIGHT = 100;
    private final double AG_BORDERTHICKNESS = 10;
    private final double AG_DELTA_X = 200;
    
    //Values used for the location  of the character's shoulder for shooting location
    private final double SHOULDER_X = 100;
    private final double SHOULDER_Y = 725;

    public void addToPane(Node node) {
        pane.getChildren().add(node);
    }

    public void removeFromPane(Node node) {
        pane.getChildren().remove(node);
    }

    @FXML
    public void mouseMoved(MouseEvent event) {
        mouseX = event.getSceneX();
        mouseY = (pane.getHeight() - event.getSceneY());

        mouseAim = new Point((int) mouseX, (int) mouseY);
        gunRotationAngle(mouseAim, gunPivot);

        coordinates.setText("MouseX: " + mouseX + "MouseY: " + mouseY);
    }

    @FXML
    public void mouseClicked(MouseEvent event) {

        acceleration = new Vector(0, GRAVITY);

        //Checks if the projectile is within the bounds of an antigravity region and inverts the gravity if it is. ---------------PROBABLY REMOVE---------------------
        if (isWithinAntiGravity) {
            acceleration = new Vector(0, -GRAVITY);
        }

        //Supplies the method with values for the mouse's "x" and "y" coordinates
        mouseX = event.getSceneX();
        mouseY = (pane.getHeight() - event.getSceneY());


        //---------Changes the type of projectile depending on the gun--------
        if (radioButtonFireGun.isSelected()) {
            projectile = new Projectile(new Vector(SHOULDER_X, SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "fire");
        }

        if (radioButtonIceGun.isSelected()) {
            projectile = new Projectile(new Vector(SHOULDER_X, SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "ice");
        }

        if (radioButtonAGGun.isSelected()) {
            projectile = new Projectile(new Vector(SHOULDER_X, SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "antigravity");
        }

        if (radioButtonPortalGun.isSelected()) {
            
            if(portalInIsActive && portalOutIsActive)
            {
                closePortal();
                projectile = new Projectile(new Vector(SHOULDER_X , SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "portalIn");
            }
            if(portalInIsActive == false){
                projectile = new Projectile(new Vector(SHOULDER_X , SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "portalIn");
            }else{
                projectile = new Projectile(new Vector(SHOULDER_X , SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "portalOut");
            }
        }

        //This ensures that only one projectile can exist at one time and if it can exist, it adds it to the scene
        if (arrayListProjectiles.isEmpty()) {
            addToPane(projectile.getCircle());
            objectList.add(projectile);
            arrayListProjectiles.add(projectile);
        }
    }

    public void gunRotationAngle(Point mouseAim, Point gunPivot) {
        theta = Math.atan2(mouseAim.y - gunPivot.y, mouseAim.x - gunPivot.x);
        
        double angle = Math.toDegrees(theta);
        gunImage.setRotate(-angle);
    }
    
    //---Unused---
    public Point gunTip()
    {       
        Point gunTip = new Point((int)((gunImage.getLayoutX()) + Math.cos(theta) * GUN_LENGTH), (int)((gunImage.getLayoutY()) - Math.sin(theta) * GUN_LENGTH));
        return gunTip;
    }

    //----------PORTAL AND ANTIGRAVITY BEHAVIOR METHODS------------

    public void openPortal()
    {
        if(portalInIsActive == false)
        {
            portalIn = new Portal(new Vector(projectile.getPosition().getX(), projectile.getPosition().getY()), PORTAL_WIDTH, PORTAL_HEIGHT);
            objectList.add(portalIn);
            addToPane(portalIn.getRectangle());
            portalIn.getRectangle().setFill(AssetManager.getPortalIn());
            portalInIsActive = true;
        }
        else
        {
            portalOut = new Portal(new Vector(projectile.getPosition().getX(), projectile.getPosition().getY()), PORTAL_WIDTH, PORTAL_HEIGHT);
            objectList.add(portalOut);
            addToPane(portalOut.getRectangle());
            portalOut.getRectangle().setFill(AssetManager.getPortalOut());
            portalOutIsActive = true;
        }
    }

    //Method that closes portals and should only be called when two portals are active
    public void closePortal()
    {        
        portalInIsActive = false;        
        portalIn.getRectangle().setFill(null);        
        objectList.remove(portalIn);
        removeFromPane(portalIn.getRectangle());
        
        portalOutIsActive = false;
        portalOut.getRectangle().setFill(null);
        objectList.remove(portalOut);
        removeFromPane(portalOut.getRectangle());
    }

    public void openAntiGravity()
    {        
        agLeftSide = new AntiGravity(new Vector(projectile.getCircle().getCenterX() - AG_DELTA_X, projectile.getCircle().getCenterY()), AG_BORDERTHICKNESS, pane.getPrefHeight());
        
        //Rectangle agLeftSideRectangle = new Rectangle(agLeftSide.getRectangleWidth(), agLeftSide.getRectangleHeight());
        //Bounds boundAGLeftSide = agLeftSideRectangle.getBoundsInParent();
        //agLeftSide.getRectangle().setFill(AssetManager.getAntiGravitySide());
        addToPane(agLeftSide.getRectangle());
        
        agRightSide = new AntiGravity(new Vector(projectile.getCircle().getCenterX() + AG_DELTA_X, projectile.getCircle().getCenterY()), AG_BORDERTHICKNESS, pane.getPrefHeight());
        
        //Rectangle agRightSideRectangle = new Rectangle(agRightSide.getRectangleWidth(), agRightSide.getRectangleHeight());
        //Bounds boundAGRightSide = agRightSideRectangle.getBoundsInParent();
        //agRightSide.getRectangle().setFill(AssetManager.getAntiGravitySide());
        addToPane(agRightSide.getRectangle());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lastFrameTime = 0.0f;
        long initialTime = System.nanoTime();

        AssetManager.preloadAllAssets();


        ToggleGroup group = new ToggleGroup();
        radioButtonFireGun.setToggleGroup(group);
        radioButtonIceGun.setToggleGroup(group);
        radioButtonAGGun.setToggleGroup(group);
        radioButtonPortalGun.setToggleGroup(group);


        //Image of MainCharacter
        character.setImage(AssetManager.getCharacterImage());

        //Image Gun
        //if(selectedGunType == "fire")
        gunImage.setImage(AssetManager.getGunFire_Img());
        radioButtonFireGun.setSelected(true);

        gunPivot = new Point();
        gunPivot.setLocation(100, 100);

        //Creating Edge objects
        edgeFloor = new Edge(new Vector(0, pane.getPrefHeight() + 50), pane.getPrefWidth() + 50, 1);
        edgeRoof = new Edge(new Vector(0, 0), pane.getPrefWidth() + 50, 1);
        edgeLeftWall = new Edge(new Vector(0, 0), 1, pane.getPrefHeight() + 50);
        edgeRightWall = new Edge(new Vector(pane.getPrefWidth() + 50, 0), 1, pane.getPrefHeight() + 50);

        //Adding Edges to the pane so that collisions can be detected with the edge
        addToPane(edgeFloor.getRectangle());
        addToPane(edgeRoof.getRectangle());
        addToPane(edgeLeftWall.getRectangle());
        addToPane(edgeRightWall.getRectangle());

        //Adding edges to the objectList so that their existance within the program can be monitored
        objectList.add(edgeFloor);
        objectList.add(edgeRoof);
        objectList.add(edgeLeftWall);
        objectList.add(edgeRightWall);

        new AnimationTimer() {
            @Override
            public void handle(long now) {
                try {
                    double currentTime = (now - initialTime) / 1000000000.0;
                    double frameDeltaTime = currentTime - lastFrameTime;
                    lastFrameTime = currentTime;

                    for (GameObject obj : objectList) {
                        if (obj != null) {
                            obj.updateRectangle(frameDeltaTime);
                            obj.updateCircle(frameDeltaTime);
                        }
                    }
                } catch (Exception e) {}

                if(group.getSelectedToggle() == radioButtonFireGun){
                    gunImage.setImage(AssetManager.getGunFire_Img());
                }

                if(group.getSelectedToggle() == radioButtonIceGun){
                    gunImage.setImage(AssetManager.getGunIce_Img());
                }

                if(group.getSelectedToggle() == radioButtonAGGun){
                    gunImage.setImage(AssetManager.getGunAntiGravity_Img());
                }

                if(group.getSelectedToggle() == radioButtonPortalGun){
                    gunImage.setImage(AssetManager.getGunPortalIn_Img());
                }



                for (int i = 0; i < arrayListProjectiles.size(); i++) {
                    //AudioClip tempBounce = AssetManager.getBounce();  //---------------------SOUND IS BROKEN---------------
                    Projectile tempProjectile = arrayListProjectiles.get(i);

                    Circle projectileCircle = tempProjectile.getCircle();
                    Bounds boundProjectileCircle = projectileCircle.getBoundsInParent();

                    //SETTING BOUNDS

                    //Bound Floor
                    Rectangle rectangleEdgeFloor = edgeFloor.getRectangle();
                    Bounds boundRectangleEdgeFloor = rectangleEdgeFloor.getBoundsInParent();

                    //Bound Roof
                    Rectangle rectangleEdgeRoof = edgeRoof.getRectangle();
                    Bounds boundRectangleEdgeRoof = rectangleEdgeRoof.getBoundsInParent();

                    //Bound LeftWall
                    Rectangle rectangleEdgeLeftWall = edgeLeftWall.getRectangle();
                    Bounds boundRectangleEdgeLeftWall = rectangleEdgeLeftWall.getBoundsInParent();

                    //Bound RightWall
                    Rectangle rectangleEdgeRightWall = edgeRightWall.getRectangle();
                    Bounds boundRectangleEdgeRightWall = rectangleEdgeRightWall.getBoundsInParent();
                    
                    
                    //----------THE BOUNDS FOR AG and PORTALS DO NOT WORK BECUASE WE ARE CREATING THEM
                    //----------INSIDE THE INITIALISE METHOD AND THEY NEED TO BE OUTSIDE OF IT SOMEHOW
                    
                    
                    /*                    
                    //Rectangle rectangleAGLeftSide = agLeftSide.getRectangle();
                    //Bounds boundAGLeftSide = rectangleAGLeftSide.getBoundsInParent();
                    
                    //Rectangle rectangleAGRightSide = agRightSide.getRectangle();
                    //Bounds boundAGRightSide = rectangleAGRightSide.getBoundsInParent();

                    
                    
                    //Bound portalIn
                    //Rectangle rectanglePortalIn = portalIn.getRectangle();
                    //Bounds boundRectanglePortalIn = rectanglePortalIn.getBoundsInParent();

                    //Bound portalOut
                    //Rectangle rectanglePortalOut = portalOut.getRectangle();
                    //Bounds boundRectanglePortalOut = rectanglePortalOut.getBoundsInParent();
                    
                    */
                    //----------COLLISIONS--------


                        //FLOOR
                        if (boundProjectileCircle.intersects(boundRectangleEdgeFloor)) {
                            
                            //Check for fire and ice
                            if(tempProjectile.getType().equalsIgnoreCase("fire") || tempProjectile.getType().equalsIgnoreCase("ice"))
                            {
                                ++counterBounces;
                                //Moves projectile away from edge by 1 radius
                                tempProjectile.setPosition(new Vector(tempProjectile.getPosition().getX(), tempProjectile.getPosition().getY() - PROJECTILE_RADIUS));

                                //Inverts the projectile's velocity
                                tempProjectile.setVelocity(new Vector(tempProjectile.getVelocity().getX(), -tempProjectile.getVelocity().getY()));
                            }

                            //Check for antigravity
                            if(tempProjectile.getType().equalsIgnoreCase("antigravity"))
                            {                                
                                openAntiGravity();
                                
                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                                //------TODO-------
                            }

                            //Check for portalIn
                            if(tempProjectile.getType().equalsIgnoreCase("portalIn"))
                            {
                                openPortal();

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }

                            //Check for PortalOut
                            if(tempProjectile.getType().equalsIgnoreCase("portalOut"))
                            {
                                openPortal();

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }
                        }

                        //ROOF
                        if (boundProjectileCircle.intersects(boundRectangleEdgeRoof)) {
                            
                            /*
                            //Bound portalIn
                            Rectangle rectanglePortalIn = new Rectangle(portalIn.getRectangleWidth(), portalIn.getRectangleHeight());
                            Bounds boundRectanglePortalIn = rectanglePortalIn.getBoundsInParent();

                            //Bound portalOut
                            Rectangle rectanglePortalOut = new Rectangle(portalOut.getRectangleWidth(), portalOut.getRectangleHeight());
                            Bounds boundRectanglePortalOut = rectanglePortalOut.getBoundsInParent();
                            */

                            //Check fire and ice
                            if(tempProjectile.getType().equalsIgnoreCase("fire") || tempProjectile.getType().equalsIgnoreCase("ice"))
                            {
                                ++counterBounces;
                                //Moves the projectile away from edge by 1 radius
                                tempProjectile.setPosition(new Vector(tempProjectile.getPosition().getX(), tempProjectile.getPosition().getY() + PROJECTILE_RADIUS));

                                //Inverts the projectile's velocity
                                tempProjectile.setVelocity(new Vector(tempProjectile.getVelocity().getX(), -tempProjectile.getVelocity().getY()));
                            }

                            //Check for antigravity
                            if(tempProjectile.getType().equalsIgnoreCase("antigravity"))
                            {
                                openAntiGravity();
                                
                                agLeftSide.getRectangle().setFill(AssetManager.getAntiGravitySide());
                                agRightSide.getRectangle().setFill(AssetManager.getAntiGravitySide());
                                
                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                                //------TODO-------
                            }

                            //Check for portalIn
                            if(tempProjectile.getType().equalsIgnoreCase("portalIn"))
                            {
                                openPortal();

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }

                            //Check for PortalOut
                            if(tempProjectile.getType().equalsIgnoreCase("portalOut"))
                            {
                                openPortal();

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }
                        }

                        //LEFT WALL
                        if(boundProjectileCircle.intersects(boundRectangleEdgeLeftWall)){
                            
                           /*
                            //Bound portalIn
                            Rectangle rectanglePortalIn = new Rectangle(portalIn.getRectangleWidth(), portalIn.getRectangleHeight());
                            Bounds boundRectanglePortalIn = rectanglePortalIn.getBoundsInParent();

                            //Bound portalOut
                            Rectangle rectanglePortalOut = new Rectangle(portalOut.getRectangleWidth(), portalOut.getRectangleHeight());
                            Bounds boundRectanglePortalOut = rectanglePortalOut.getBoundsInParent();
                            */

                            //Check for fire, ice and antigravity
                            if(tempProjectile.getType().equalsIgnoreCase("fire") || tempProjectile.getType().equalsIgnoreCase("ice") || tempProjectile.getType().equalsIgnoreCase("antigravity"))
                            {
                                ++counterBounces;
                                //Moves the projectile away from edge by 1 radius
                                tempProjectile.setPosition(new Vector(tempProjectile.getPosition().getX() + PROJECTILE_RADIUS, tempProjectile.getPosition().getY()));

                                //Inverts the projectile's velocity
                                tempProjectile.setVelocity(new Vector(-tempProjectile.getVelocity().getX(), tempProjectile.getVelocity().getY()));
                            }

                            //Check for portalIn
                            if(tempProjectile.getType().equalsIgnoreCase("portalIn"))
                            {
                                openPortal();

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }

                            //Check for PortalOut
                            if(tempProjectile.getType().equalsIgnoreCase("portalOut"))
                            {
                                openPortal();

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }


                        }
                        //RIGHT WALL
                        if(boundProjectileCircle.intersects(boundRectangleEdgeRightWall)){
                            
                            /*
                            //Bound portalIn
                            Rectangle rectanglePortalIn = new Rectangle(portalIn.getRectangleWidth(), portalIn.getRectangleHeight());
                            Bounds boundRectanglePortalIn = rectanglePortalIn.getBoundsInParent();

                            //Bound portalOut
                            Rectangle rectanglePortalOut = new Rectangle(portalOut.getRectangleWidth(), portalOut.getRectangleHeight());
                            Bounds boundRectanglePortalOut = rectanglePortalOut.getBoundsInParent();
                            */

                            //check for fire, ice and antigravity
                            if(tempProjectile.getType().equalsIgnoreCase("fire") || tempProjectile.getType().equalsIgnoreCase("ice") || tempProjectile.getType().equalsIgnoreCase("antigravity"))
                            {
                                ++counterBounces;
                                //Moves the projectile away from edge by 1 radius
                                tempProjectile.setPosition(new Vector(tempProjectile.getPosition().getX() - PROJECTILE_RADIUS, tempProjectile.getPosition().getY()));

                                //Inverts the projectile's velocity
                                tempProjectile.setVelocity(new Vector(-tempProjectile.getVelocity().getX(), tempProjectile.getVelocity().getY()));
                            }

                            //Check for portalIn
                            if(tempProjectile.getType().equalsIgnoreCase("portalIn"))
                            {
                                openPortal();

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }

                            //Check for PortalOut
                            if(tempProjectile.getType().equalsIgnoreCase("portalOut"))
                            {
                                openPortal();

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }

                        }
                        
                        /*
                        
                        if(projectileCircle.getCenterX() > agLeftSide.getRectangle().getX() && projectileCircle.getCenterX() < agRightSide.getRectangle().getX())
                        {
                            isWithinAntiGravity = true;                            
                            projectile.setVelocity(new Vector(0, -GRAVITY));
                        }

*/
                        
                        //if(boundProjectileCircle.intersects())

                        if (counterBounces == MAX_NUMBER_OF_BOUNCES) {
                            counterBounces = 0;
                            objectList.remove(arrayListProjectiles.get(0));
                            arrayListProjectiles.remove(0);
                            removeFromPane(tempProjectile.getCircle());
                        }
                        //tempBounce.play(); --------------THE SOUND DOESNT WORK
                     //Collision with Sides


                    projectile = tempProjectile;

                }//for (int i = 0; i < arrayListProjectiles.size(); i++)

            }//public void handle(long now)

        }.start();

    }

}
